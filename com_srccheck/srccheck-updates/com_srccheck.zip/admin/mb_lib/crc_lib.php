<?php
/**
 **************************************************************************
 Source Files Check - component that verifies the integrity of Joomla files
 **************************************************************************
 * @author    Maciej Bednarski (Green Line) <maciek.bednarski@gmail.com>
 * @copyright Copyright (C) 2020 Green Line. All Rights Reserved.
 * @license   GNU General Public License version 3, or later
 * @version   HEAD
 **************************************************************************
 */

/*
 * Definition for debug
 */

//define( 'MB_DEBUG', __CLASS__."::".__FUNCTION__ . " " );

// No direct access to this file
defined('_JEXEC') or die('Restricted access');
/*
     * 0 - new file;
     * 1 - checked file;
     * 2 - changed file;
     * 3 - deleted file;
*/
define( 'FILE_STATUS_NEW'       ,'0' );
define( 'FILE_STATUS_VERIFIED'  ,'1' );
define( 'FILE_STATUS_DELETED'   ,'2' );

define( 'FILE_CHECKED_STATUS_INVALID'   ,'0' );
define( 'FILE_CHECKED_STATUS_VALID'     ,'1' );

define( 'SILENCE_MODE'          ,'1' );
define( 'NORMAL_MODE'           ,'2' );

//define( 'TA_LOCALISATION',  JPATH_ADMINISTRATOR.DIRECTORY_SEPARATOR.'components'.DIRECTORY_SEPARATOR.'com_srccheck'.DIRECTORY_SEPARATOR.'mb_lib' );
define( 'TA_LOCALISATION',  'p:\tmp' );
define( 'TA_FILENAME',      'ta.zip' );
define( 'TA_PASSWORD',      ')9*CA^gbaH!oij#kj' );
define( 'TA_MODE_INIT',     1 );

include_once (JPATH_ADMINISTRATOR.DIRECTORY_SEPARATOR.'components'.DIRECTORY_SEPARATOR.'com_srccheck'.DIRECTORY_SEPARATOR.'mb_lib'.DIRECTORY_SEPARATOR.'trusted_archive_lib.php');

function listFilesTree( $dir, &$result = array() ){
    $files = scandir($dir);
    foreach($files as $key => $value)
    {
        $path = $dir.DIRECTORY_SEPARATOR.$value;
        if( !is_dir($path) ){
            $result[] = array(dirname($path), $value, md5_file($path) );
	}elseif ($value != '.' && $value != '..') {
            listFilesTree( $path, $result );
	}
    }
    return $result;
}

function clear_crc_tmp(){
    // Update CRC information
    // Get a db connection.
    $db = JFactory::getDbo();

    $query = $db->getQuery(true);
    $query = "DELETE FROM #__crc_tmp;";
    $db->setQuery($query);
    $db->execute();
}

function generate_crc_tmp( $dir ){
echo "generate_crc_tmp: START<br>";

    clear_crc_tmp();
    
    $lft = listFilesTree( $dir );

    // Get a db connection.
    $db = JFactory::getDbo();

    // Create a new query object.
    $query = $db->getQuery(true);

    // Insert columns.
    $columns = array('path', 'filename', 'crc');

    $query
        ->insert($db->quoteName('#__crc_tmp'))
        ->columns($db->quoteName($columns));

    $i=0;
    $j=0;

    foreach($lft as $v)
    {
        // Insert values.
        $v_query = array( $db->quote($v[0]), $db->quote($v[1]), $db->quote($v[2]) );

        // Prepare the insert query.
        $query->values(implode(',', $v_query));

        if($i++ > 400)
        {
            $db->setQuery($query);
            $db->execute();

            // Recreate a new query object.
            $query = $db->getQuery(true);

            $query
                ->insert($db->quoteName('#__crc_tmp'))
                ->columns($db->quoteName($columns));

            $i=0;
        }
        $j++;
    }

    // Set the query using our newly populated query object and execute it.
    $db->setQuery($query);
    $db->execute();
echo "generate_crc_tmp: STOP<br>";
}

function update_crc_from_tmp($veryfied=0){
echo "update_crc_from_tmp: START<br>";
    if(!$veryfied) $veryfied=FILE_STATUS_NEW;

    // Update CRC information
    // Get a db connection.
    $db = JFactory::getDbo();
echo "update_crc_from_tmp: 1<br>";

    /*
     * Add new files
     */
    $query = $db->getQuery(true);
    $query = "INSERT INTO #__crc_files (path, filename, status) SELECT path, filename,".$veryfied." FROM #__crc_tmp ct LEFT JOIN #__crc_files cf USING (path, filename) WHERE cf.filename is NULL;";
    $db->setQuery($query);
    $db->execute();
echo "update_crc_from_tmp: 2<br>";

    /*
     * Add date check to history
     */
    $query = $db->getQuery(true);
    $query = "INSERT INTO #__crc_check_history (users_id) VALUES('".JFactory::getUser()->get('id')."');";
//    $query = "INSERT INTO #__crc_check_history (users_id) VALUES('949');";
    $db->setQuery($query);
    $db->execute();
echo "update_crc_from_tmp: 3<br>";

    /*
     * Write check data from tmp table to check table
     */
    $query = $db->getQuery(true);
    $query = "INSERT INTO #__crc_check (crc_files_id, crc, veryfied, crc_check_history_id) SELECT cf.id, ct.crc, ".$veryfied.", LAST_INSERT_ID() FROM #__crc_files cf, #__crc_tmp ct WHERE cf.path = ct.path AND cf.filename = ct.filename;";
    $db->setQuery($query);
    $db->execute();
echo "update_crc_from_tmp: 4<br>";

    /*
     * Update deleted files.
     */
    if(!$veryfied) {
        $query = $db->getQuery(true);
        $query = "UPDATE #__crc_files cf LEFT JOIN #__crc_check cc ON cf.id = cc.crc_files_id AND cc.crc_check_history_id = (SELECT max(cch.id) FROM #__crc_check_history cch) SET cf.status = " .FILE_STATUS_DELETED. " WHERE cc.id is NULL;";
        $db->setQuery($query);
        $db->execute();
    }
echo "update_crc_from_tmp: END<br>";
}

function update_trusted_archive_from_tmp( $rootPatch, $ta_filename = TA_LOCALISATION.DIRECTORY_SEPARATOR.TA_FILENAME, $mode = TA_MODE_INIT )
{
echo __FUNCTION__. " " . "Start<br>";
echo __FUNCTION__. " " . "ta_filename = " . $ta_filename . "<br>";

    // Initialize New Trusted Archive
    $tarchive = new TrustedArchive( $rootPatch, $ta_filename );
//    $tarchive->openTrustedArchive();

echo __FUNCTION__. " " . "filename = " . $tarchive->showTrustedArchiveLocalization() . "<br>";
echo __FUNCTION__. " " . "status = " . $tarchive->status . " " . $tarchive->showStatusMessage() . "<br>";

    if( $mode == TA_MODE_INIT )
    {
echo __FUNCTION__ . " " . " Init Mode<br>";

        /*
         *  Get data from #__crc_tmp
         */
        // Get a db connection.
        $db = JFactory::getDbo();
        $query = $db->getQuery(true);
        $query = "SELECT * FROM #__crc_tmp;";
echo __FUNCTION__. " " . "query = >>" . $query . "<<<br>";
        $db->setQuery($query);
        $db->execute();

        $results = $db->loadObjectList();
    
        foreach ( $results as $i => $row )
        {
            $fileListToArchive[] = $row->path.DIRECTORY_SEPARATOR.$row->filename;
//echo __FUNCTION__ . " " . "[$i] path =>>" . $row->path . "<< filename = >>" . $row->filename . "<< crc = >>" . $row->crc . "<< fileListToArchive=>". $fileListToArchive[$i] . "<<<br>";
        }
        $tarchive->addFilesToTrustedArchive( $fileListToArchive );
    }

    $tarchive->close();
echo __FUNCTION__ . " " . " Stop<br>";
}

function update_veryfied_crc(){
    // Update CRC information
    // Get a db connection.
    $db = JFactory::getDbo();

    $query = $db->getQuery(true);
    $query = "UPDATE #__crc_check ccc, #__crc_check ccp, (SELECT max(cid.id) c_id, max(pid.id) p_id FROM #__crc_check_history cid, #__crc_check_history pid WHERE pid.id < cid.id) ids SET ccc.veryfied = ".FILE_STATUS_VERIFIED." WHERE ccc.crc_check_history_id = ids.c_id AND ccp.crc_check_history_id = ids.p_id AND ccc.crc_files_id = ccp.crc_files_id AND ccc.crc = ccp.crc AND ccp.veryfied = ".FILE_STATUS_VERIFIED.";";
    $db->setQuery($query);
    $db->execute();
}

function erase_checked_files( $crc_files_id )
{
echo "Start Function: erase_checked_files <br>";
    // Get a db connection.
    $db = JFactory::getDbo();
    $db->transactionStart();

    $i=0;
    foreach ($crc_files_id AS $cci)
    {
        $tmp_cci[$i]=$cci;

        if( $i++ > 400 )
        {
            // Delete crc_check records.
            $query = $db->getQuery(true);
            $query  -> delete($db->quoteName( '#__crc_check', 'cc' ))
                    -> where( $db->quoteName( 'cc.crc_files_id' ) . ' IN (' . implode(',',$tmp_cci) . ') ' );
echo "<br>111.1 " . $query . "<br>";
            $db->setQuery($query);
            $db->execute();

            // Delete crc_files records.
            $query = $db->getQuery(true);
            $query  -> delete($db->quoteName( '#__crc_files', 'cf' ))
                    -> where( $db->quoteName('cf.id') . ' IN (' . implode(',',$tmp_cci) . ') ' );
echo "<br>111.2 " . $query . "<br>";
            $db->setQuery($query);
            $db->execute();
            $i=0;
        }
    }
    
    // Delete crc_check records.
    $query = $db->getQuery(true);
    $query  -> delete($db->quoteName( '#__crc_check'))
            -> where( $db->quoteName( 'crc_files_id' ) . ' IN (' . implode(',',$tmp_cci) . ') ' );
echo "<br>222.1 " . $query . "<br>";
// die();
    $db->setQuery($query);
    $db->execute();

    // Delete crc_files records.
    $query = $db->getQuery(true);
    $query  -> delete($db->quoteName( '#__crc_files'))
            -> where( $db->quoteName('id') . ' IN (' . implode(',',$tmp_cci) . ') ' );
echo "<br>222.2 " . $query . "<br>";
    $db->setQuery($query);
    $db->execute();

    $db->transactionCommit();
echo "End Function: erase_checked_files <br>";
};

function validate_checked_files( $crc_files_id )
{
echo __CLASS__."::".__FUNCTION__ . " " . "Start Function: validate_checked_files <br>";

    // Get a db connection.
    $db = JFactory::getDbo();
    $db->transactionStart();

    $i=0;
    foreach ($crc_files_id AS $cci)
    {
        $tmp_cci[$i]=$cci;
        
        if( $i++ > 400 )
        {

            // Create a new query object.
            $query = $db->getQuery(true);
            $query  -> update($db->quoteName( '#__crc_check', 'ccu' ))
                    -> join('INNER', '(SELECT cc_max.crc_files_id AS crc_files_id, MAX(cc_max.crc_check_history_id) AS crc_check_history_id FROM #__crc_check AS cc_max WHERE cc_max.crc_files_id IN (' . implode(',',$tmp_cci) . ') GROUP BY cc_max.crc_files_id) AS cc ON cc.crc_files_id = ccu.crc_files_id AND cc.crc_check_history_id = ccu.crc_check_history_id' )
                    -> set($db->quoteName('ccu.veryfied') . " = " . FILE_CHECKED_STATUS_VALID );

echo __CLASS__."::".__FUNCTION__ . " " . "<br>111 " . $query . "<br>";
            $db->setQuery($query);
            $db->execute();
            $i=0;
        }
    }
    // Create a new query object.
    $query = $db->getQuery(true);
    $query  -> update($db->quoteName( '#__crc_check', 'ccu' ))
            -> join('INNER', '(SELECT cc_max.crc_files_id AS crc_files_id, MAX(cc_max.crc_check_history_id) AS crc_check_history_id FROM #__crc_check AS cc_max WHERE cc_max.crc_files_id IN (' . implode(',',$tmp_cci) . ') GROUP BY cc_max.crc_files_id) AS cc ON cc.crc_files_id = ccu.crc_files_id AND cc.crc_check_history_id = ccu.crc_check_history_id' )
            -> set($db->quoteName('ccu.veryfied') . " = " . FILE_CHECKED_STATUS_VALID );
echo __CLASS__."::".__FUNCTION__ . " " . "<br>222 " . $query . "<br>";
    $db->setQuery($query);

    $db->execute();
    $db->transactionCommit();
echo __CLASS__."::".__FUNCTION__ . " " . "End Function: validate_checked_files <br>";
}

function mb_verify()
{
echo __CLASS__."::".__FUNCTION__ . " " . ":Start<br>";
    $db = JFactory::getDbo();
    $db->transactionStart();

    generate_crc_tmp( JPATH_ROOT );
    update_crc_from_tmp(false);
    update_veryfied_crc();
    $db->transactionCommit();
echo __CLASS__."::".__FUNCTION__ . " " . ":Stop<br>";
}